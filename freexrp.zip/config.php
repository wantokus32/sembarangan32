<?

$UserAgent = "Mozilla/5.0 (Linux; Android 9; SM-A750GN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.93 Mobile Safari/537.36";
$Cookie = "lt=5e1748854f2b9%3Ae31197e48bb49dddc30de60399afd444d9f49f4a6cb6deb4a1f9a4b72ff7741c77";
$username = "zein07";
$id = "137592";
